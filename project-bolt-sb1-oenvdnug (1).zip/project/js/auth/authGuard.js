import { isAuthenticated } from '../utils/authUtils.js';
import { CONFIG } from '../config/config.js';

// Protect routes that require authentication
const currentPath = window.location.pathname;
const isLoginPage = currentPath.includes('login.html');

if (!isAuthenticated() && !isLoginPage) {
    window.location.replace(CONFIG.ROUTES.LOGIN);
} else if (isAuthenticated() && isLoginPage) {
    window.location.replace(CONFIG.ROUTES.APP);
}