export async function generateArticle(formData) {
    const seoPrompt = generateSEOPrompt(formData);
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${formData.apiKey}`
        },
        body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [{
                role: "user",
                content: seoPrompt
            }],
            temperature: 0.7
        })
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Failed to generate article');
    }

    const data = await response.json();
    return formatArticleWithSchema(data.choices[0].message.content, formData);
}

function generateSEOPrompt(formData) {
    return `Write a ${formData.voice.toLowerCase()} article about "${formData.title}" in ${formData.language} with approximately ${formData.wordCount} words.

    SEO Requirements:
    - Include these keywords naturally: ${formData.keywords}
    - Use ${formData.headingStructure} heading structure
    - Optimize for readability and search engines
    - Include meta description: ${formData.metaDescription}
    - Add relevant internal linking suggestions
    - Implement proper header hierarchy
    - Include a table of contents
    - Add alt text suggestions for images
    - Optimize paragraph length for readability
    `;
}

function formatArticleWithSchema(content, formData) {
    const schema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": formData.title,
        "description": formData.metaDescription,
        "keywords": formData.keywords,
        "articleBody": content,
        "language": formData.language
    };

    return `
        <script type="application/ld+json">
            ${JSON.stringify(schema, null, 2)}
        </script>
        ${content}
    `;
}