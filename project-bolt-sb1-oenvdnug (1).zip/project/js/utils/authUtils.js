import { CONFIG } from '../config/config.js'

/**
 * Set authentication data
 * @param {string} license - Verified license code
 */
export function setAuth(license) {
  const authData = {
    license,
    timestamp: Date.now(),
    expiresAt: Date.now() + CONFIG.AUTH.SESSION_DURATION
  }
  
  localStorage.setItem(CONFIG.AUTH.STORAGE_KEY, JSON.stringify(authData))
}

/**
 * Check if user is authenticated
 * @returns {boolean} Authentication status
 */
export function isAuthenticated() {
  try {
    const authData = JSON.parse(localStorage.getItem(CONFIG.AUTH.STORAGE_KEY))
    
    if (!authData) return false
    
    // Check if session has expired
    if (Date.now() > authData.expiresAt) {
      logout()
      return false
    }
    
    return true
  } catch {
    return false
  }
}

/**
 * Clear authentication data
 */
export function logout() {
  localStorage.removeItem(CONFIG.AUTH.STORAGE_KEY)
}