const COOKIE_DEFAULTS = {
    path: '/',
    sameSite: 'Strict'
};

export function setCookie(name, value, days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    
    document.cookie = [
        `${name}=${encodeURIComponent(value)}`,
        `expires=${date.toUTCString()}`,
        `path=${COOKIE_DEFAULTS.path}`,
        `SameSite=${COOKIE_DEFAULTS.sameSite}`
    ].join('; ');
}

export function getCookie(name) {
    const cookies = document.cookie.split('; ');
    const cookie = cookies.find(c => c.startsWith(name + '='));
    return cookie ? decodeURIComponent(cookie.split('=')[1]) : null;
}

export function deleteCookie(name) {
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=${COOKIE_DEFAULTS.path}`;
}