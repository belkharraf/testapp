/**
 * Show error message with animation
 * @param {HTMLElement} element - Error message element
 * @param {string} message - Error message
 */
export function showError(element, message) {
  element.textContent = message
  element.style.display = 'block'
  
  // Reset animation
  element.classList.remove('shake')
  void element.offsetWidth // Force reflow
  element.classList.add('shake')
}

/**
 * Toggle loading state
 * @param {HTMLElement} button - Button element
 * @param {HTMLElement} input - Input element
 * @param {boolean} isLoading - Loading state
 */
export function toggleLoading(button, input, isLoading) {
  button.classList.toggle('loading', isLoading)
  input.disabled = isLoading
  button.disabled = isLoading
}