import { marked } from 'marked';

// Configure marked options
marked.setOptions({
    gfm: true,
    breaks: true,
    headerIds: true
});

export function showLoading() {
    const loadingEl = document.getElementById('loading');
    const resultEl = document.getElementById('resultContainer');
    
    if (loadingEl) loadingEl.style.display = 'block';
    if (resultEl) resultEl.style.display = 'none';
}

export function hideLoading() {
    const loadingEl = document.getElementById('loading');
    const resultEl = document.getElementById('resultContainer');
    
    if (loadingEl) loadingEl.style.display = 'none';
    if (resultEl) resultEl.style.display = 'block';
}

export function updateResults(imageUrl, article, seoAnalysis) {
    updateImage(imageUrl);
    updateArticle(article);
    updateSEOAnalysis(seoAnalysis);
}

function updateImage(imageUrl) {
    const container = document.getElementById('imageContainer');
    if (!container) return;
    
    container.innerHTML = `
        <img 
            src="${imageUrl}" 
            alt="Generated article image"
            loading="lazy"
        >
    `;
}

function updateArticle(article) {
    const container = document.getElementById('articleContainer');
    if (!container) return;
    
    // Store original markdown
    container.setAttribute('data-markdown', article);
    
    // Convert markdown to HTML with custom renderer
    const htmlContent = marked(article);
    
    container.innerHTML = `
        <div class="article-actions">
            <button onclick="copyArticle()" class="copy-button">
                <span class="copy-icon">📋</span> Copy Article
            </button>
        </div>
        <div class="generated-article">
            ${htmlContent}
        </div>
    `;
}

export function updateSEOAnalysis(analysis) {
    const container = document.getElementById('seoScoreContainer');
    if (!container) return;
    
    container.innerHTML = `
        <div class="seo-container">
            <div class="seo-score">
                <h3>SEO Score: ${analysis.score}%</h3>
                <div class="progress-bar">
                    <div 
                        class="progress" 
                        style="width: ${analysis.score}%"
                        role="progressbar" 
                        aria-valuenow="${analysis.score}" 
                        aria-valuemin="0" 
                        aria-valuemax="100"
                    ></div>
                </div>
            </div>
            
            <div class="seo-analysis">
                <h3>Content Analysis</h3>
                <ul>
                    ${analysis.recommendations.map(rec => `
                        <li class="${rec.type}">
                            <span class="icon">
                                ${getIconForType(rec.type)}
                            </span>
                            ${rec.message}
                        </li>
                    `).join('')}
                </ul>
            </div>
        </div>
    `;
}

function getIconForType(type) {
    switch (type) {
        case 'success': return '✓';
        case 'warning': return '⚠';
        case 'error': return '✗';
        default: return '•';
    }
}

export async function copyArticle() {
    const container = document.getElementById('articleContainer');
    const button = container?.querySelector('.copy-button');
    
    if (!container || !button) return;
    
    const markdown = container.getAttribute('data-markdown');
    
    try {
        await navigator.clipboard.writeText(markdown);
        button.innerHTML = '<span class="copy-icon">✓</span> Copied!';
        button.classList.add('copied');
        
        setTimeout(() => {
            button.innerHTML = '<span class="copy-icon">📋</span> Copy Article';
            button.classList.remove('copied');
        }, 2000);
    } catch (err) {
        console.error('Copy failed:', err);
        alert('Failed to copy article');
    }
}