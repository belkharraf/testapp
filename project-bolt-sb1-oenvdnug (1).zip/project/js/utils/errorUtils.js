/**
 * Handle API errors and return user-friendly messages
 * @param {Error} error - Original error
 * @returns {Error} Error with user-friendly message
 */
export function handleApiError(error) {
  if (error.name === 'AbortError') {
    return new Error('Request timed out. Please try again.')
  }

  if (!navigator.onLine) {
    return new Error('No internet connection. Please check your network.')
  }

  console.error('API Error:', error)
  return new Error('Verification failed. Please try again later.')
}