// Constants
const AUTH_COOKIE_NAME = 'auth_token';
const CODE_COOKIE_NAME = 'purchase_code';
const COOKIE_EXPIRY_DAYS = 7;

/**
 * Set a cookie with expiration
 * @param {string} name - Cookie name
 * @param {string} value - Cookie value
 * @param {number} days - Days until expiration
 */
function setCookie(name, value, days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    const expires = `expires=${date.toUTCString()}`;
    document.cookie = `${name}=${value};${expires};path=/;SameSite=Strict`;
}

/**
 * Get cookie value by name
 * @param {string} name - Cookie name
 * @returns {string|null} Cookie value or null if not found
 */
function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) {
        return parts.pop().split(';').shift();
    }
    return null;
}

/**
 * Delete cookie by name
 * @param {string} name - Cookie name
 */
function deleteCookie(name) {
    document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
}

/**
 * Check if user is authenticated
 * @returns {boolean} Authentication status
 */
export function checkAuth() {
    const authToken = getCookie(AUTH_COOKIE_NAME);
    const currentPath = window.location.pathname;
    const isLoginPage = currentPath.includes('login.html');
    
    if (!authToken && !isLoginPage) {
        window.location.replace('login.html');
        return false;
    }
    
    if (authToken && isLoginPage) {
        window.location.replace('index.html');
        return true;
    }
    
    return !!authToken;
}

/**
 * Logout user and redirect to login page
 */
export function logout() {
    deleteCookie(AUTH_COOKIE_NAME);
    deleteCookie(CODE_COOKIE_NAME);
    window.location.replace('login.html');
}

/**
 * Set authentication status
 * @param {string} purchaseCode - Verified purchase code
 */
export function setAuth(purchaseCode) {
    const authToken = btoa(Date.now().toString()); // Simple token generation
    setCookie(AUTH_COOKIE_NAME, authToken, COOKIE_EXPIRY_DAYS);
    setCookie(CODE_COOKIE_NAME, purchaseCode, COOKIE_EXPIRY_DAYS);
}