import { logout } from './auth/authService.js';
import { generateArticle, generateImage } from './services/openaiService.js';
import { analyzeSEO } from './services/seoService.js';
import { showLoading, hideLoading, updateResults, copyArticle } from './utils/uiUtils.js';
import { initWordCountSlider } from './components/wordCountSlider.js';
import { CONFIG } from './config/config.js';

// Initialize components
document.addEventListener('DOMContentLoaded', () => {
    initWordCountSlider();
    initLogoutButton();
    initArticleForm();
});

// Make copyArticle available globally
window.copyArticle = copyArticle;

function initLogoutButton() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            logout();
            window.location.href = CONFIG.ROUTES.LOGIN;
        });
    }
}

function initArticleForm() {
    const articleForm = document.getElementById('articleForm');
    if (articleForm) {
        articleForm.addEventListener('submit', handleArticleSubmit);
    }
}

async function handleArticleSubmit(e) {
    e.preventDefault();
    
    const submitButton = e.target.querySelector('button[type="submit"]');
    if (!submitButton || submitButton.disabled) return;
    
    // Disable submit button and show loading state
    submitButton.disabled = true;
    submitButton.innerHTML = `
        <div class="spinner-small"></div>
        <span>Generating...</span>
    `;
    
    const formData = {
        apiKey: document.getElementById('apiKey').value,
        title: document.getElementById('title').value,
        language: document.getElementById('language').value,
        voice: document.getElementById('voice').value,
        wordCount: document.getElementById('wordCount').value
    };

    try {
        showLoading();
        
        const [article, imageUrl] = await Promise.all([
            generateArticle(formData),
            generateImage(formData.apiKey, formData.title)
        ]);

        const seoAnalysis = analyzeSEO(article);
        updateResults(imageUrl, article, seoAnalysis);
    } catch (error) {
        alert('Error: ' + error.message);
    } finally {
        hideLoading();
        // Re-enable submit button and restore original text
        submitButton.disabled = false;
        submitButton.innerHTML = `
            <span class="button-icon">✨</span>
            Generate Article & Image
        `;
    }
}