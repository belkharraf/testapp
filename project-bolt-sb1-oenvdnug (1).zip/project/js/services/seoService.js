export function analyzeSEO(article) {
    const analysis = {
        score: 0,
        recommendations: []
    };

    // Content Length Analysis
    const wordCount = article.split(/\s+/).length;
    if (wordCount < 300) {
        analysis.recommendations.push({
            type: 'warning',
            message: 'Article length is too short for optimal SEO (recommended: >300 words)'
        });
    } else {
        analysis.recommendations.push({
            type: 'success',
            message: 'Article length is good for SEO'
        });
    }

    // Heading Analysis
    const hasHeadings = /#{1,6}\s/.test(article);
    if (hasHeadings) {
        analysis.recommendations.push({
            type: 'success',
            message: 'Article contains proper heading structure'
        });
    } else {
        analysis.recommendations.push({
            type: 'error',
            message: 'No headings found in the article'
        });
    }

    // Paragraph Length Analysis
    const paragraphs = article.split(/\n\n+/);
    const longParagraphs = paragraphs.filter(p => p.split(/\s+/).length > 150).length;
    if (longParagraphs > 0) {
        analysis.recommendations.push({
            type: 'warning',
            message: 'Some paragraphs are too long (recommended: <150 words)'
        });
    } else {
        analysis.recommendations.push({
            type: 'success',
            message: 'Paragraph lengths are optimal for readability'
        });
    }

    // Calculate overall score
    const total = analysis.recommendations.length;
    const successes = analysis.recommendations.filter(r => r.type === 'success').length;
    analysis.score = Math.round((successes / total) * 100);

    return analysis;
}