import { API_CONFIG } from '../config/apiConfig.js';

export async function generateArticle(formData) {
    const response = await fetch(`${API_CONFIG.OPENAI_API_URL}/chat/completions`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${formData.apiKey}`
        },
        body: JSON.stringify({
            model: API_CONFIG.MODEL,
            messages: [{
                role: "user",
                content: generatePrompt(formData)
            }],
            temperature: 0.7
        })
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Failed to generate article');
    }

    const data = await response.json();
    return data.choices[0].message.content;
}

export async function generateImage(apiKey, title) {
    const response = await fetch(`${API_CONFIG.OPENAI_API_URL}/images/generations`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            prompt: `Create a professional and relevant image for an article about: ${title}`,
            n: 1,
            size: API_CONFIG.IMAGE_SIZE
        })
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Failed to generate image');
    }

    const data = await response.json();
    return data.data[0].url;
}

function generatePrompt(formData) {
    return `Write a ${formData.voice.toLowerCase()} article about "${formData.title}" in ${formData.language} with approximately ${formData.wordCount} words.

    Requirements:
    - Use proper heading hierarchy (H1, H2, H3) with markdown syntax (# for H1, ## for H2, etc.)
    - Include relevant keywords naturally
    - Optimize for readability and search engines
    - Include a table of contents
    - Add alt text suggestions for images
    - Optimize paragraph length for readability (max 150 words per paragraph)
    - Format the content using markdown syntax
    - Use bullet points and numbered lists where appropriate
    - Include proper spacing between sections
    `;
}