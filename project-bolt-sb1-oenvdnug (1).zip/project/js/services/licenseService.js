import { CONFIG } from '../config/config.js'
import { handleApiError } from '../utils/errorUtils.js'

/**
 * Verify license code
 * @param {string} license - License code to verify
 * @returns {Promise<boolean>} Verification result
 */
export async function verifyLicense(license) {
  try {
    const params = new URLSearchParams({
      license: license.trim(),
      product: CONFIG.LICENSE_API.PRODUCT_SLUG
    })

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), CONFIG.LICENSE_API.TIMEOUT)

    const response = await fetch(`${CONFIG.LICENSE_API.PROXY_URL}?${params}`, {
      method: 'GET',
      signal: controller.signal
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const result = await response.text()
    return result.toLowerCase() === 'valid'
  } catch (error) {
    throw handleApiError(error)
  }
}