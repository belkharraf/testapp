/**
 * Initialize word count slider functionality
 */
export function initWordCountSlider() {
    const slider = document.getElementById('wordCount');
    const valueDisplay = document.getElementById('wordCountValue');
    
    if (!slider || !valueDisplay) return;
    
    // Update value display on slider change
    function updateValue() {
        valueDisplay.textContent = slider.value;
    }
    
    slider.addEventListener('input', updateValue);
    updateValue(); // Initial value
}