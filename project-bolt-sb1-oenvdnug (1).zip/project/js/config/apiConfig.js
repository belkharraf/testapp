export const API_CONFIG = {
    OPENAI_API_URL: 'https://api.openai.com/v1',
    IMAGE_SIZE: "1024x1024",
    MODEL: "gpt-3.5-turbo"
};