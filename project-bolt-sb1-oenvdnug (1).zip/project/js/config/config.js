export const CONFIG = {
    LICENSE_API: {
        PROXY_URL: 'https://licensevalidation.mohammedbelkharraf.workers.dev//verify',
        PRODUCT_SLUG: 'all-in-one-radio',
        TIMEOUT: 15000
    },
    AUTH: {
        STORAGE_KEY: 'auth_data',
        SESSION_DURATION: 7 * 24 * 60 * 60 * 1000 // 7 days
    },
    ROUTES: {
        LOGIN: '/login.html',
        APP: '/index.html'
    }
};