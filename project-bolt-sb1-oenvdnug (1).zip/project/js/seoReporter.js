export function generateSEOReport(article, seoScore, seoAnalysis) {
    const timestamp = new Date().toISOString();
    
    return `
SEO Analysis Report
Generated: ${timestamp}

${seoScore}

Detailed Analysis:
${seoAnalysis}

Content Statistics:
- Word Count: ${countWords(article)}
- Character Count: ${article.length}
- Paragraph Count: ${countParagraphs(article)}
- Average Words Per Paragraph: ${calculateAverageWordsPerParagraph(article)}
- Readability Score: ${calculateReadabilityScore(article)}

Recommendations Summary:
${generateRecommendationsSummary(seoAnalysis)}
    `.trim();
}

function countWords(text) {
    return text.trim().split(/\s+/).length;
}

function countParagraphs(text) {
    return text.split(/\n\s*\n/).length;
}

function calculateAverageWordsPerParagraph(text) {
    const paragraphs = text.split(/\n\s*\n/);
    const totalWords = paragraphs.reduce((acc, p) => acc + countWords(p), 0);
    return Math.round(totalWords / paragraphs.length);
}

function calculateReadabilityScore(text) {
    // Simplified Flesch-Kincaid readability score implementation
    const words = text.trim().split(/\s+/).length;
    const sentences = text.split(/[.!?]+/).length;
    const syllables = countSyllables(text);
    
    return Math.round(206.835 - 1.015 * (words / sentences) - 84.6 * (syllables / words));
}

function countSyllables(text) {
    return text.toLowerCase()
        .replace(/[^a-z]/g, '')
        .replace(/[^aeiouy]*[aeiouy]+/g, 'a')
        .length;
}

function generateRecommendationsSummary(analysis) {
    const recommendations = analysis.split('\n')
        .filter(line => line.includes('✓') || line.includes('⚠') || line.includes('✗'))
        .map(line => line.trim());

    return recommendations.join('\n');
}