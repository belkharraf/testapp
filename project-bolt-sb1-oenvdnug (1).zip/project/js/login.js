import { verifyLicense } from './services/licenseService.js'
import { setAuth } from './utils/authUtils.js'
import { showError, toggleLoading } from './utils/domUtils.js'
import { CONFIG } from './config/config.js'

// DOM Elements
const loginForm = document.getElementById('loginForm')
const licenseInput = document.getElementById('licenseCode')
const errorElement = document.getElementById('errorMessage')
const submitButton = loginForm.querySelector('button')

// Redirect if already authenticated
if (localStorage.getItem(CONFIG.AUTH.STORAGE_KEY)) {
  window.location.href = CONFIG.ROUTES.APP
}

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault()
  
  const license = licenseInput.value.trim()
  
  // Validate input
  if (!license || license.length < 5) {
    showError(errorElement, 'Please enter a valid license code')
    return
  }
  
  // Start verification
  toggleLoading(submitButton, licenseInput, true)
  errorElement.style.display = 'none'
  
  try {
    const isValid = await verifyLicense(license)
    
    if (isValid) {
      setAuth(license)
      window.location.href = CONFIG.ROUTES.APP
    } else {
      showError(errorElement, 'Invalid license code')
    }
  } catch (error) {
    showError(errorElement, error.message)
  } finally {
    toggleLoading(submitButton, licenseInput, false)
  }
})