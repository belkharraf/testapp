export async function analyzeSEO(article, formData) {
    const analysis = {
        score: 0,
        recommendations: []
    };

    // Keyword Analysis
    const keywordAnalysis = analyzeKeywords(article, formData.keywords);
    analysis.recommendations.push(...keywordAnalysis.recommendations);
    analysis.score += keywordAnalysis.score;

    // Content Structure Analysis
    const structureAnalysis = analyzeStructure(article, formData.headingStructure);
    analysis.recommendations.push(...structureAnalysis.recommendations);
    analysis.score += structureAnalysis.score;

    // Readability Analysis
    const readabilityAnalysis = analyzeReadability(article);
    analysis.recommendations.push(...readabilityAnalysis.recommendations);
    analysis.score += readabilityAnalysis.score;

    // Meta Description Analysis
    const metaAnalysis = analyzeMetaDescription(formData.metaDescription);
    analysis.recommendations.push(...metaAnalysis.recommendations);
    analysis.score += metaAnalysis.score;

    // Normalize score to percentage
    analysis.score = Math.round(analysis.score / 4);

    return analysis;
}

function analyzeKeywords(article, keywords) {
    const keywordList = keywords.split(',').map(k => k.trim().toLowerCase());
    const articleText = article.toLowerCase();
    const results = {
        score: 0,
        recommendations: []
    };

    keywordList.forEach(keyword => {
        const count = (articleText.match(new RegExp(keyword, 'g')) || []).length;
        const density = (count * keyword.split(' ').length / articleText.split(' ').length) * 100;

        if (density === 0) {
            results.recommendations.push({
                type: 'error',
                message: `Keyword "${keyword}" not found in the content`
            });
        } else if (density < 0.5) {
            results.recommendations.push({
                type: 'warning',
                message: `Keyword "${keyword}" density (${density.toFixed(2)}%) is low`
            });
        } else if (density > 2.5) {
            results.recommendations.push({
                type: 'warning',
                message: `Keyword "${keyword}" density (${density.toFixed(2)}%) is too high`
            });
        } else {
            results.recommendations.push({
                type: 'success',
                message: `Keyword "${keyword}" has optimal density (${density.toFixed(2)}%)`
            });
        }
    });

    results.score = calculateKeywordScore(results.recommendations);
    return results;
}

function analyzeStructure(article, headingStructure) {
    // Implementation of heading structure analysis
    return {
        score: 25,
        recommendations: [
            {
                type: 'success',
                message: 'Proper heading hierarchy implemented'
            }
        ]
    };
}

function analyzeReadability(article) {
    // Implementation of readability analysis
    return {
        score: 25,
        recommendations: [
            {
                type: 'success',
                message: 'Content is easily readable and well-structured'
            }
        ]
    };
}

function analyzeMetaDescription(metaDescription) {
    const length = metaDescription.length;
    const results = {
        score: 0,
        recommendations: []
    };

    if (length < 120) {
        results.recommendations.push({
            type: 'warning',
            message: 'Meta description is too short (recommended: 120-160 characters)'
        });
    } else if (length > 160) {
        results.recommendations.push({
            type: 'warning',
            message: 'Meta description is too long (recommended: 120-160 characters)'
        });
    } else {
        results.recommendations.push({
            type: 'success',
            message: 'Meta description length is optimal'
        });
    }

    results.score = length >= 120 && length <= 160 ? 25 : 15;
    return results;
}

function calculateKeywordScore(recommendations) {
    const successCount = recommendations.filter(r => r.type === 'success').length;
    return (successCount / recommendations.length) * 25;
}