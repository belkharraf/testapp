export function validateForm(formData) {
    const validations = [
        validateApiKey(formData.apiKey),
        validateTitle(formData.title),
        validateKeywords(formData.keywords),
        validateMetaDescription(formData.metaDescription),
        validateWordCount(formData.wordCount)
    ];

    const errors = validations.filter(v => !v.isValid);

    if (errors.length > 0) {
        alert(errors.map(e => e.message).join('\n'));
        return false;
    }

    return true;
}

function validateApiKey(apiKey) {
    if (!apiKey || apiKey.length < 20) {
        return {
            isValid: false,
            message: 'Please enter a valid OpenAI API key'
        };
    }
    return { isValid: true };
}

function validateTitle(title) {
    if (!title || title.length < 5) {
        return {
            isValid: false,
            message: 'Title must be at least 5 characters long'
        };
    }
    return { isValid: true };
}

function validateKeywords(keywords) {
    if (!keywords) {
        return {
            isValid: false,
            message: 'Please enter at least one keyword'
        };
    }
    return { isValid: true };
}

function validateMetaDescription(description) {
    if (!description || description.length < 120 || description.length > 160) {
        return {
            isValid: false,
            message: 'Meta description must be between 120 and 160 characters'
        };
    }
    return { isValid: true };
}

function validateWordCount(wordCount) {
    const count = parseInt(wordCount);
    if (isNaN(count) || count < 100 || count > 2000) {
        return {
            isValid: false,
            message: 'Word count must be between 100 and 2000'
        };
    }
    return { isValid: true };
}