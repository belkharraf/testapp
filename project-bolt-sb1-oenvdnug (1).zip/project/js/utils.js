export function handleCopy(text) {
    navigator.clipboard.writeText(text)
        .then(() => alert('Article copied to clipboard!'))
        .catch(err => alert('Failed to copy article: ' + err.message));
}

export function handleDownload(text, filename) {
    const blob = new Blob([text], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}