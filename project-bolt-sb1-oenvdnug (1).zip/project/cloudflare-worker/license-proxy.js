// License verification proxy worker
addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request))
})

async function handleRequest(request) {
  // CORS headers
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }

  // Handle OPTIONS request
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      headers: corsHeaders
    })
  }

  // Get URL parameters
  const url = new URL(request.url)
  const license = url.searchParams.get('license')
  const product = url.searchParams.get('product')

  if (!license || !product) {
    return new Response('Missing parameters', {
      status: 400,
      headers: corsHeaders
    })
  }

  try {
    // Forward request to BMSUtilities
    const apiUrl = `https://bmsutilities.com/Registrations2/ValidateLicense?License=${encodeURIComponent(license)}&Product=${encodeURIComponent(product)}`
    const response = await fetch(apiUrl)
    const result = await response.text()

    return new Response(result, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'text/plain'
      }
    })
  } catch (error) {
    return new Response('Verification failed', {
      status: 500,
      headers: corsHeaders
    })
  }
}